import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class SQL {
	
	final String tabelle_test="db_film";
	
	//Need some global Variables
	Connection con;
	
	//Nur für den Entwickler richtig
	private void p(String to_print){System.out.print(to_print);}
	private void np(String to_print){System.out.println(to_print);}
	
	//Die Funktion wird nur gebraucht um die Verbindung zum SQL-Server zu checken
	public int check_connection(String serverIP,String port,String databaseName,String username,String password){	
		
		System.out.println("Jetzt wird die Verbindung zum Server geprueft. 0-> alles gut; -1-> Fehler");
		
		try{
			/*
			serverIP="141.45.91.40";
			port="3306";
			databaseName="s0559122_test";
			username="s0559122";
			password="62cs:2cu";
			*/
			//Das ist das was das Internet sagt
			//String host="jdbc:mysql://141.45.91.40:3306/s0559122_test?autoReconnect=true&useSSL=true";
			//String host="jdbc:mysql://141.45.91.40:3306/s0559122_test?autoReconnect=true&useSSL=true?connectTimeout=10000"; 10 sec warten bevor man abbricht. 
			//Es läuft aber auch ohne das AutoReconnect
			
			String host="jdbc:mysql://"+serverIP+":"+port+"/"+databaseName+"?useSSL=true";
			//con=DriverManager.getConnection(host,username,password);
			
			//Test query
			Statement state=con.createStatement();
			ResultSet result=state.executeQuery("Select * from "+tabelle_test+";");
			
			if(result.getFetchSize()!=0){
				np("Success");
				return 0;
			}else{
				np("Failed to connect");
				return -1;
			}
			/*
			Class.forName("com.mysql.jdbc.Driver");//.newInstance();
			Connection con=DriverManager.getConnection(host,user,password);
			
			String abfrage="SELECT * FROM uhrzeit;";

			//con.setReadOnly(true);
			
			Statement state=con.createStatement();
			
			ResultSet rs=state.executeQuery(abfrage);
			 
			
			while(rs.next()){

				System.out.println(rs.getString(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "+rs.getString(4));
				
			}
			*/
			
		}catch(Exception e){
			System.out.println("Fehler: "+e);
		}
		return -1;
	}
	public ArrayList<String> query(String userInput,String auswahl,ArrayList<String> ergebnisListe){//Vielleicht eine Liste übergegeben wo das ganze ergebnis drinnensteht (film a,film b,film c, ...)
		
			if(!parseUserInput(userInput)){
			try{
				String help="";
				switch (auswahl){	
				case "Filme":
					{
						help="Select * from "+tabelle_test+" where name=\""+userInput+"\";";
						break;
					}
				case "Autoren":
					{
						//calculateResult("Select * from db_film where name=\""+userInput+"\";");
						break;
					}
				default:
					{
						break;
					}
				}
			
				np("Jetzt beginnt die Abfrage:");
		
				Statement state=con.createStatement();
				ResultSet rs=state.executeQuery(help);
				System.out.println("Result:");
				while(rs.next()){
					
					//Am Anfang oder am Ende der Liste noch mit angeben wieviel Spalten zu einer Abfrage gehören, Bsp.: zu einen Film gehört der Name,Autor, Länge -> dann ist die Länge 3
					ergebnisListe.add(rs.getString(1));
					ergebnisListe.add(rs.getString(2));
					ergebnisListe.add(rs.getString(3));
					ergebnisListe.add(rs.getString(4));
					//System.out.println(rs.getString(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "+rs.getString(4));
				}
				
				int t=1;
				np("Print all result from the resultList");
				
				for(int i=0;i<ergebnisListe.size();i++){
				
					p(ergebnisListe.get(i));
					p(" | ");
					if(i==t){
						t++;
						t=t*i;
						np("");
					}
				}
				}catch(Exception e){
					System.out.println("Fehler: "+e);
				}			
			}else{
				Injection();
			}
		return ergebnisListe;
	}
	//Alle Spalten werden in die ergebnisListe geschrieben
	public ArrayList<String> getAllColumns(String tabellenName,ArrayList<String> ergebnisListe){
		
		try{
			
			Statement state=con.createStatement();
			ResultSet rs=state.executeQuery("show columns from "+tabellenName);
			while(rs.next()){
				ergebnisListe.add(rs.getString(1));
			}
		}catch(Exception e){
			
			np("ERROR: TabellenName Funktion ist etwas passiert.");
		}
		return ergebnisListe;
	}
	private	boolean parseUserInput(String toParse){
		//Try to check that the user does not try SQL Injection
		
		if(!toParse.toLowerCase().contains("drop")){
			if(!toParse.toLowerCase().contains("--")){
				if(!toParse.toLowerCase().contains("pwd")){
					if(!toParse.toLowerCase().contains("trusted")){
						if(!toParse.toLowerCase().contains("exec")){
							if(!toParse.toLowerCase().contains("/")){
								if(!toParse.toLowerCase().contains("\\")){
									if(!toParse.toLowerCase().contains("?")){
										return false;
									}
								}
							}
						}
					}
				}
			}
		}
		np("Versuchte SQL Injection!");
		return true;
	}
	private void Injection() {
		JOptionPane.showMessageDialog(null,"Versuchte SQL Injection!","SQL Injection",JOptionPane.ERROR_MESSAGE);
		System.exit(0);
	}


}//END CLASS SQL

