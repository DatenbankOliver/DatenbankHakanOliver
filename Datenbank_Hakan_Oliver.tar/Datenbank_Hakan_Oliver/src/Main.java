
public class Main{

	@SuppressWarnings("unchecked")
	public static void main(String [] args){
		
		GUI gui=new GUI();
	}
}
