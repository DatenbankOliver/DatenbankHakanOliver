import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.TabExpander;

public class GUI extends JFrame implements ActionListener {
	
	//#define statements
	public static final int SIZE =100;	
	
	public final String list_combobox[]={"Filme","Autoren","Kinos","Wo laeuft der Film im Kino?","Alle Filme in Kino ...","Alle Filme", "Alle Kinos"};
	public final int TEXT_FIELD_LOCATION_X=110;
	public final int TEXT_FIELD_DISTANCE=10;
	public final int SIZE_OF_TEXTFIELD_X=200;
	public final int SIZE_OF_TEXTFIELD_Y=20;
	public final int LABLE_LOCATION_X=20;
	public final int LABLE_LOCATION_Y=10;
	public final int LABEL_SIZE_X=75;
	public final int LABEL_SIZE_Y=20;
	public final int SIZE_MAIN_WINDOW_X=1200;
	public final int SIZE_MAIN_WINDOW_Y=600;
	public final int LOCATION_MAIN_WINDOW_X=0;
	public final int LOCATION_MAIN_WINDOW_Y=0;
	
	//End of #define Statements
	
	public JFrame frame=new JFrame("Datenbank");
	public JPanel pnl=new JPanel();
	public JLabel []lbl=new JLabel[SIZE];
	public JButton []btn=new JButton[SIZE];
	public JTextField []tf = new JTextField[SIZE];
	public JList<String>[]my_list=new JList[SIZE];
	public JScrollPane []jsp=new JScrollPane[SIZE];
	//public JTable table;
	
	public Vector<Vector<String>> data=new Vector<Vector<String>>();
	public Vector<String> rowA=new Vector<String>();
	public Vector<String> rowB=new Vector<String>();
	public Vector<String> titel=new Vector<String>();
	//public DefaultTableModel tablemodel;
	
	public JFrame MySQLServer=new JFrame();
	public JPanel pnl_SQL=new JPanel();
	public JLabel []lbl_SQL=new JLabel[SIZE];
	public JButton btn_SQL=new JButton();
	public JTextField []tf_SQL = new JTextField[SIZE];
	public JPasswordField jpw_SQL=new JPasswordField();
	
	//Drop Down Menu
	public JComboBox cbox=new JComboBox(list_combobox);
	public DefaultListModel<String> []model=new DefaultListModel[SIZE];
	
	public SQL sql=new SQL();
	//public Logic_Btn logic_Action=new Logic_Btn(); 
	
	//String spalten[]=new String[SIZE];
	
	public GUI(){//Konstruktor
	
		initMainField();
		initConnectionField();
		//btn_SQL.doClick();
		/*
		MySQLServer.setVisible(true);
		MySQLServer.repaint();
		*/
	}
	public void actionPerformed (ActionEvent ae){//ActionListener

		//Button Main Field
        if(ae.getSource() == this.btn[0]){
        	
        	//logic_Action.Action_Btn_Search();  
		}
        //Button SQL-Connection Field
		if(ae.getSource()==this.btn_SQL){ 
			
			//logic_Action.Action_Btn_SQL();
		}
	}//End ActionListener	
	public void initConnectionField(){
		
		MySQLServer.setTitle("Connection to MySQL Server");
		MySQLServer.setSize(350, 150);
		MySQLServer.setLocation(1000, 300);
		MySQLServer.setResizable(false);
		
		pnl_SQL.setLayout(null);
		
		MySQLServer.add(pnl_SQL);
		
		//Label ServerIP
		lbl_SQL[0]=new JLabel();
		lbl_SQL[0].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y);
		lbl_SQL[0].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[0].setText("Server IP:");
		
		//Label Port
		lbl_SQL[3]=new JLabel();
		lbl_SQL[3].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*3);
		lbl_SQL[3].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[3].setText("Port:");
		
		//Label Datenbank
		lbl_SQL[4]=new JLabel();
		lbl_SQL[4].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*5);
		lbl_SQL[4].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[4].setText("Datenbank:");
		
		//Label Username
		lbl_SQL[1]=new JLabel();
		lbl_SQL[1].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*7);
		lbl_SQL[1].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[1].setText("Username:");
		
		//Label Password
		lbl_SQL[2]=new JLabel();
		lbl_SQL[2].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*9);
		lbl_SQL[2].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[2].setText("Password:");
		
		//Textfield ServerIP
		tf_SQL[0]=new JTextField();
		tf_SQL[0].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE);
		tf_SQL[0].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Port
		tf_SQL[2]=new JTextField();
		tf_SQL[2].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*3);
		tf_SQL[2].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);

		//Textfield Datenbank
		tf_SQL[3]=new JTextField();
		tf_SQL[3].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*5);
		tf_SQL[3].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Username
		tf_SQL[1]=new JTextField();
		tf_SQL[1].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*7);
		tf_SQL[1].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Password
		jpw_SQL.setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*9);
		jpw_SQL.setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		//nachher löschen
		jpw_SQL.setText("a");
		
		//Connect Button
		btn_SQL.setLocation(135, 110);
		btn_SQL.setSize(150, 20);
		btn_SQL.setText("Connect ...");
		btn_SQL.addActionListener(this);
		
		//Alles dem Panel pnl_SQL hinzufügen 
		pnl_SQL.add(jpw_SQL);
		pnl_SQL.add(btn_SQL);
		pnl_SQL.add(lbl_SQL[0]);
		pnl_SQL.add(lbl_SQL[1]);
		pnl_SQL.add(lbl_SQL[2]);
		pnl_SQL.add(lbl_SQL[3]);
		pnl_SQL.add(lbl_SQL[4]);
		pnl_SQL.add(tf_SQL[0]);
		pnl_SQL.add(tf_SQL[1]);
		pnl_SQL.add(tf_SQL[2]);
		pnl_SQL.add(tf_SQL[3]);
		
	}
	public void initMainField(){
		
		//Function SetBounds() = SetLocation() + SetSize() 
		//The 3 functions have the same result
		
		frame.setSize(SIZE_MAIN_WINDOW_X,SIZE_MAIN_WINDOW_Y);
		frame.setLocation(LOCATION_MAIN_WINDOW_X,LOCATION_MAIN_WINDOW_Y);
		//frame.setLocation(1000, 400);
		frame.setResizable(false);
		
		pnl.setLayout(null);
		pnl.setBackground(Color.pink);
		frame.add(pnl);
		
		lbl[0]=new JLabel();
		lbl[0].setText("Suchbegriff:");
		lbl[0].setBounds(0, 10, 200, 20);
		
		lbl[1]=new JLabel();
		lbl[1].setBounds(260, 10, 100, 20);
		lbl[1].setText("Filter");
		
		lbl[2]=new JLabel();
		lbl[2].setText("Console:");
		lbl[2].setBounds(10, 400, 200, 20);
		
		btn[0]=new JButton();
		btn[0].setLocation(475, 30);
		btn[0].setSize(100, 25);
		btn[0].setText("Suchen");
		btn[0].addActionListener(this);		
		
		/*
		btn[1]=new JButton();
		btn[1].setBounds(600, 30, 100, 25);//Set the Location and the Size
										   //Loc_X,Loc_Y,Size_X,Size_Y
		btn[1].setText("Next >");
		btn[1].addActionListener(this);
		*/
		tf[0] =new JTextField();
		tf[0].setSize(250, 25);
		tf[0].setLocation(1, 30);
		
		cbox.setLocation(260, 30);
		cbox.setSize(200, 30);
		//cbox.addActionListener(this);
		
		//Konsole Liste
		model[0]=new DefaultListModel<String>();
		
		//
		my_list[0]=new JList<String>(model[0]);
		my_list[0].setBackground(Color.yellow);
	
		jsp[1]=new JScrollPane();
		jsp[1].getViewport().add(my_list[0]);
		jsp[1].setBounds(10, 425, 500, 150);
		jsp[1].setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		//Die Liste brauch ich nicht hinzuzufügen den das ist schon in dem scrollpanel drin
		//pnl.add(my_list[0]);
		//pnl.add(jsp[0]);
		
		String titels[]={"A","B"};
		//tablemodel=new DefaultTableModel(titels,0);
		
		
		//table=new JTable(tablemodel);
		
		/*rowA.add("eins");
		rowA.add("eins_B");
		
		rowB.add("zwei");
		rowB.add("zweite Spalte");
		
		data.add(rowA);
		data.add(rowB);
		
		titel.add("A");
		titel.add("B");
		
		
		table=new JTable(data,titel);
		
		jsp[0]=new JScrollPane(table);
		jsp[0].setBounds(200, 100, 300, 300);
		jsp[0].setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		//pnl.add(table);
		jsp[0].setVisible(true);
		
		//table.setVisible(true);
		
		int size=tablemodel.getColumnCount();
		Vector newDatas=logic_Action.createDataVector("row",size);
		tablemodel.addRow(newDatas);
		
		size=tablemodel.getRowCount();
		
		
		
		pnl.add(jsp[0]);
		*/
		pnl.add(jsp[1]);
		pnl.add(lbl[1]);
		pnl.add(lbl[2]);
		pnl.add(cbox);
		pnl.add(lbl[0]);
		pnl.add(btn[0]);
		//pnl.add(btn[1]);
		pnl.add(tf[0]);
	}



}


