import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.TabExpander;

public class GUI extends JFrame implements ActionListener {
	
	//#define statements
	public final String list_combobox[]={"Filme","Autoren","Kinos","Wo laeuft der Film im Kino?","Alle Filme in Kino ...","Alle Filme", "Alle Kinos"};
	public final static String TITEL="Datenbank Oliver, Hakan";
	
	public static final int SIZE =100;	
	public final int TEXT_FIELD_LOCATION_X=110;
	public final int TEXT_FIELD_DISTANCE=10;
	public final int SIZE_OF_TEXTFIELD_X=200;
	public final int SIZE_OF_TEXTFIELD_Y=20;
	public final int LABLE_LOCATION_X=20;
	public final int LABLE_LOCATION_Y=10;
	public final int LABEL_SIZE_X=75;
	public final int LABEL_SIZE_Y=20;
	public final int SIZE_MAIN_WINDOW_X=1200;
	public final int SIZE_MAIN_WINDOW_Y=600;
	public final int LOCATION_MAIN_WINDOW_X=0;
	public final int LOCATION_MAIN_WINDOW_Y=0;
	
	//End of #define Statements
	
	public static int multiple=0;
	
//	public static JFrame frame=new JFrame("Datenbank");
	//pnl[0]=SQL
	//pnl[0]=Connection
	public static JPanel []pnl=new JPanel[SIZE];
	public static JLabel []lbl=new JLabel[SIZE];
	public static JButton []btn=new JButton[SIZE];
	public static JTextField []tf = new JTextField[SIZE];
	public static JList<String>[]my_list=new JList[SIZE];
	public static JScrollPane []jsp=new JScrollPane[SIZE];
	public static JTable table;
	
	public Vector<Vector<String>> data=new Vector<Vector<String>>();
	public Vector<String> rowA=new Vector<String>();
	public Vector<String> rowB=new Vector<String>();
	public Vector<String> titel=new Vector<String>();
	public DefaultTableModel tablemodel;
	
	//public static JFrame MySQLServer=new JFrame();
	//public static JPanel pnl_SQL=new JPanel();
	public static JLabel []lbl_SQL=new JLabel[SIZE];
	public static JButton btn_SQL=new JButton();
	public static JTextField []tf_SQL = new JTextField[SIZE];
	public static JPasswordField jpw_SQL=new JPasswordField();
	
	//Drop Down Menu
	public JComboBox cbox=new JComboBox(list_combobox);
	public DefaultListModel<String> []model=new DefaultListModel[SIZE];
	
	public SQL sql=new SQL();
	//NICHT das static weg machen dann funktioniert nichts mehr
	public static Logic_Btn logic_Action=new Logic_Btn(); 
	
	public CardLayout cl;//=new CardLayout();
	public JPanel cards;//=new JPanel(new CardLayout());
	public Container pane;    
    //String spalten[]=new String[SIZE];
	
	public GUI(){//Konstruktor
		
		super(TITEL);
		//**********
		//Variable Mutliple brauch den er öffnet immer zwei Fenster; mit der Logik verhinder ich das zwei identische fenster geöffnet werden; keine ahnung warum der das überhaupt macht
		try{
			add();
			System.out.println("multiple= "+this.multiple);
			if(this.multiple!=2){
				
				setSize(350, 150);
				setLocation(1000, 300);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				initMainField();
				initConnectionField();
				
				cards = new JPanel(new CardLayout());
				cards.add(pnl[0], "a");
				cards.add(pnl[1], "b");
				
				pane=getContentPane();
				pane.add(cards);
				setVisible(true);
			
			}else{
				System.out.println("Fehler multiple ist ==2");
			}
		}catch(Exception e){
			System.out.println("Error: "+e);
		}
		//****************
	}
	
	@Override
	public void actionPerformed (ActionEvent ae){//ActionListener
		
		//CardLayout cl=(CardLayout)(cards.getLayout());
		cl=(CardLayout)(cards.getLayout());
		//Button Main Field
        if(ae.getSource() == this.btn[0]){
        	
        	System.out.println("Button "+btn[0].getText()+" pressed");
        	logic_Action.Action_Btn_Search();  
		}
        //Button SQL-Connection Field
        else if(ae.getSource()==this.btn_SQL){
			
			System.out.println("Button "+btn_SQL.getText()+" pressed");
			logic_Action.Action_Btn_SQL();
		}
        //Button addEintrag
        else if(ae.getSource()==btn[1]){
        	
        	System.out.println("Button addEintrag");
        	logic_Action.addEintrag();
        }
        else if(ae.getSource()==btn[3]){//Add Spalte Button
        	
        	System.out.println("Button addSpalte");
        	logic_Action.addSpalte("steht in der Spalte", "spaltenname");
        }
        
	}//End ActionListener
	
	public void initConnectionField(){
		
		setTitle("Connection to MySQL Server");
		
		pnl[0]=new JPanel();
		pnl[0].setBackground(Color.yellow);
		pnl[0].setLayout(null);
		/*
		MySQLServer.setTitle("Connection to MySQL Server");
		MySQLServer.setSize(350, 150);
		MySQLServer.setLocation(1000, 300);
		MySQLServer.setResizable(false);
		
		setSize(350, 150);
		setLocation(1000, 300);
		setResizable(false);
		*/
		
		//pnl_SQL.setLayout(null);
		
		//MySQLServer.add(pnl_SQL);
		//add(pnl[0]);
		
		//Label ServerIP
		lbl_SQL[0]=new JLabel();
		lbl_SQL[0].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y);
		lbl_SQL[0].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[0].setText("Server IP:");
		
		//Label Port
		lbl_SQL[3]=new JLabel();
		lbl_SQL[3].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*3);
		lbl_SQL[3].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[3].setText("Port:");
		
		//Label Datenbank
		lbl_SQL[4]=new JLabel();
		lbl_SQL[4].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*5);
		lbl_SQL[4].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[4].setText("Datenbank:");
		
		//Label Username
		lbl_SQL[1]=new JLabel();
		lbl_SQL[1].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*7);
		lbl_SQL[1].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[1].setText("Username:");
		
		//Label Password
		lbl_SQL[2]=new JLabel();
		lbl_SQL[2].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*9);
		lbl_SQL[2].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[2].setText("Password:");
		
		//Textfield ServerIP
		tf_SQL[0]=new JTextField();
		tf_SQL[0].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE);
		tf_SQL[0].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Port
		tf_SQL[2]=new JTextField();
		tf_SQL[2].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*3);
		tf_SQL[2].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);

		//Textfield Datenbank
		tf_SQL[3]=new JTextField();
		tf_SQL[3].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*5);
		tf_SQL[3].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Username
		tf_SQL[1]=new JTextField();
		tf_SQL[1].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*7);
		tf_SQL[1].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Password
		jpw_SQL.setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*9);
		jpw_SQL.setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		jpw_SQL.setText("a");
		
		//Connect Button
		btn_SQL.setLocation(135, 110);
		btn_SQL.setSize(150, 20);
		btn_SQL.setText("Connect ...");
		btn_SQL.addActionListener(this);
		
		//Alles dem Panel pnl_SQL hinzufügen 
		pnl[0].add(jpw_SQL);
		pnl[0].add(btn_SQL);
		pnl[0].add(lbl_SQL[0]);
		pnl[0].add(lbl_SQL[1]);
		pnl[0].add(lbl_SQL[2]);
		pnl[0].add(lbl_SQL[3]);
		pnl[0].add(lbl_SQL[4]);
		pnl[0].add(tf_SQL[0]);
		pnl[0].add(tf_SQL[1]);
		pnl[0].add(tf_SQL[2]);
		pnl[0].add(tf_SQL[3]);
		
	}
	public void initMainField(){
		
		//Function SetBounds() = SetLocation() + SetSize() 
		//The 3 functions have the same result
		
		//setSize(SIZE_MAIN_WINDOW_X,SIZE_MAIN_WINDOW_Y);
		//setLocation(LOCATION_MAIN_WINDOW_X,LOCATION_MAIN_WINDOW_Y);
		//frame.setLocation(1000, 400);
		//setResizable(false);
		
		pnl[1]=new JPanel();
		pnl[1].setLayout(null);
		pnl[1].setBackground(Color.pink);
		//frame.add(pnl);
		//add(pnl[1]);
		
		lbl[0]=new JLabel();
		lbl[0].setText("Suchbegriff:");
		lbl[0].setBounds(0, 10, 200, 20);
		
		lbl[1]=new JLabel();
		lbl[1].setBounds(260, 10, 100, 20);
		lbl[1].setText("Filter");
		
		lbl[2]=new JLabel();
		lbl[2].setText("Console:");
		lbl[2].setBounds(10, 400, 200, 20);
		
		btn[0]=new JButton("Suchen");
		btn[0].setLocation(475, 30);
		btn[0].setSize(100, 25);
		btn[0].addActionListener(this);		
		
		btn[1]=new JButton("add eintrag");
		btn[1].setBounds(600, 30, 100, 25);//Set the Location and the Size
										   //Loc_X,Loc_Y,Size_X,Size_Y
		btn[1].addActionListener(this);
		
		btn[2]=new JButton("delete eintrag");
		btn[2].setBounds(725, 30, 100, 25);
		btn[2].addActionListener(this);
		
		btn[3]=new JButton("Add spalte");
		btn[3].setBounds(850,30,100,25);
		btn[3].addActionListener(this);
		
		
		tf[0] =new JTextField();
		tf[0].setSize(250, 25);
		tf[0].setLocation(1, 30);
		
		cbox.setLocation(260, 30);
		cbox.setSize(200, 30);
		//cbox.addActionListener(this);
		
		//Konsole Liste
		model[0]=new DefaultListModel<String>();
		my_list[0]=new JList<String>(model[0]);
		my_list[0].setBackground(Color.yellow);
		
		
		jsp[1]=new JScrollPane();
		jsp[1].getViewport().add(my_list[0]);
		jsp[1].setBounds(10, 425, 500, 150);
		jsp[1].setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		/////////////////////////////////////////
		String []titels=new String[]{};
		tablemodel=new DefaultTableModel(titels,0);//Hier werden die Spalten definiert
		table=new JTable(tablemodel);//Eine Tabelle wo die tablemodel hinzugefügt wird
		
		jsp[0]=new JScrollPane(table);
		jsp[0].setBounds(10, 70, 400, 300);
		
		
		pnl[1].add(jsp[0]);
		/////////////////////////////////////////
		
		pnl[1].add(jsp[1]);
		pnl[1].add(lbl[1]);
		pnl[1].add(lbl[2]);
		pnl[1].add(cbox);
		pnl[1].add(lbl[0]);
		pnl[1].add(btn[0]);
		pnl[1].add(btn[1]);
		pnl[1].add(btn[2]);
		pnl[1].add(btn[3]);
		pnl[1].add(tf[0]);
		
	}
	public void add(){
		this.multiple++;
	}



}