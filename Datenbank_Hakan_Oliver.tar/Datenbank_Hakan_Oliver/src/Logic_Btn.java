import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;


public class Logic_Btn extends GUI{
	
	public boolean writeIntoConsole(String text){//, DefaultListModel<String>listModel, JList<String>list){
		try {
			
			model[0].addElement(text);//Add text to list
			int lastIndex=my_list[0].getModel().getSize()-1;//Need for moving the element to the bottom
			
			if(lastIndex >= 0){
				
				my_list[0].ensureIndexIsVisible(lastIndex);//Move the element to the bottom of the list
			}
			return true;
			
		} catch (Exception e) {
			System.out.println("Exception Write into Console: "+e);
			return false;
		}
	}
	public void Action_Btn_SQL(){
		
		//Save the input from Textfields into some variables  
		String serverIP=tf_SQL[0].getText();
		String username=tf_SQL[1].getText();
		String password=String.valueOf(jpw_SQL.getPassword());
		String port=tf_SQL[2].getText();
		String database=tf_SQL[3].getText();
		
		//Output only for developers
		System.out.println("ServerIP: "+serverIP);
		System.out.println("port: "+port);
		System.out.println("Datenbank: "+database);
		System.out.println("Username: "+username);
		System.out.println("Password: "+password);
		System.out.println("Passwort ist: "+password);//Password is in cleartext
		
		
		if(jpw_SQL.getPassword().length==0){				
			
			//This will execute when the Passwordfield is empty
			//Error Message will be printed
			JOptionPane.showMessageDialog(null,"Password field is empty.\nPress OK to continue.","Password Error",JOptionPane.ERROR_MESSAGE);
		
		}else{
			
			//0 for sql_connection success; -1 for failed 
			//int check=sql.check_connection(serverIP,port,database,username,password);
			int check=0;
			
			if(check==0){
				
				System.out.println("Die Verbindung zum Server steht");
				//Make the MYSQL-window invisible 
				MySQLServer.dispose();	
				
				//Make frame Windows visible
				frame.setVisible(true);
				frame.repaint();
				
			}else{
				
				//System.out.println("Error: Verbindung konnte nicht hergestellt werden.");
				//Error Message Window
				JOptionPane.showMessageDialog(null,"Could not conncet to "+serverIP+".\nPlease Check your Input and check if the server is online.\nPress OK to continue.","Connection Error",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		
		
	}
	public void Action_Btn_Search(){
	
	/*
	//https://wiki.byte-welt.net/wiki/JTable_(Tutorial)
	
	//Zeile hinzufügen
	int size=tablemodel.getColumnCount();
	Vector newDatas=createDataVector("row",size);		
	tablemodel.addRow(newDatas);
	
	//Spalte hinzufügen
	int size=tablemodel.getRowCount();
	Vector newDatas=createDataVector("column", size);
	String name=String.valueOf(tablemodel.getColumnCount());
	tablemodel.addColumn(name,newDatas);
	*/
	
	//Delete Row
	//int size = tablemodel.getRowCount();//Check ob das element zum löschen größer 0 und
										//kleiner als das letzte element
	int index = 0;
	//tablemodel.removeRow( index );
	
	
	//TableModel mydata=new MyTableModel();
	/*
	rowData.add("hello");
	rowData.add("ves");
	
	columnName.add("aec");
	columnName.add("vsdk");
	jsp[0].updateUI();
	*/
	
	
	//jsp[0]=new JScrollPane(table);
	//logic_Action.tabelleFuellen(table,jsp[0]);
	writeIntoConsole("Btn Search pressed");
	String searchString=tf[0].getText();
		
		if(!searchString.isEmpty()){
			
			//Read the Filter
			String filter=String.valueOf(cbox.getSelectedItem());
			
			writeIntoConsole("Suchstring und Filter: "+searchString+" "+filter);				
			/*
			model[0].addElement(filter);
			
			switch(auswahl){
			case "Filme"://case list_combobox[0]://Thomas fragen
				{	//Tabellenname übergeben
					sql.query(userInput,"Tabellenname_film");
					break;
				}
			case "Autoren":
				{
					//Tabellenname übergeben
					sql.query(userInput,"Tabellenname_autoren");
					break;
				}
			case "Kinos": 
				{
					sql.query(userInput, "TabellenName_kino");
					break;
				}
			case "Wo laeuft der Film im Kino?":
				{
					//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					sql.query(userInput, "Alle kinos where film=...");
					break;
				}
			case "Alle Filme in Kino ...":
				{
					//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					sql.query(userInput, "alle filme where Kino =...");
					break;
				}
			default: 
				{
					System.err.println("Fehler");
					break;
				}
			}//End switch case
			
			
			sql.query(userInput,auswahl);
			*/
		}else{
			writeIntoConsole("ERROR: Eingabefeld darf nicht leer sein");
		}
		
	}
	public Vector createDataVector(String prefix,int size){
		
		Vector vector= new Vector(size);
		
		for(int i=0; i<size;i++){
			
			vector.add(prefix+" "+size+" :"+i);
		}
		return vector;
	}
	
	
	
	
	
	
	
	
	
	
}
