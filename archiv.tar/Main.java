
public class Main{

	public static void main(String [] args){
		
		GUI gui=new GUI();
		/*
		 * Was fehlt noch:
		 * - eine scrollbalken falls die JTable nicht ausreicht
		 * - eine vernüftige aufteilung der Knöpfe und so weiter
		 * - hakans Tagesüberblick noch vernünfitg machen 
		 * - eine Uhrzeit für den Tagesüberblick
		 * - Hakan sagen das er noch eine Tabelle SQL-Connection mit dem KEY hinzufügen soll
		 * */
	}
}

