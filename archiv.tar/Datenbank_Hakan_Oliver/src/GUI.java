import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI extends JFrame implements ActionListener {
	
	//#define statements
	private static final int SIZE =100;	
	
	public final String list_combobox[]={"Filme","Autoren","Kinos","Wo laeuft der Film im Kino?","Alle Filme in Kino ...","Alle Filme", "Alle Kinos"};
	public final int TEXT_FIELD_LOCATION_X=110;
	public final int TEXT_FIELD_DISTANCE=10;
	public final int SIZE_OF_TEXTFIELD_X=200;
	public final int SIZE_OF_TEXTFIELD_Y=20;
	
	
	public final int LABLE_LOCATION_X=20;
	public final int LABLE_LOCATION_Y=10;
	public final int LABEL_SIZE_X=75;
	public final int LABEL_SIZE_Y=20;
	
	public final int SIZE_MAIN_WINDOW_X=1200;
	public final int SIZE_MAIN_WINDOW_Y=600;
	public final int LOCATION_MAIN_WINDOW_X=0;
	public final int LOCATION_MAIN_WINDOW_Y=0;
	
	//End of #define Statements
	
	private JFrame frame=new JFrame("Datenbank");
	private JPanel pnl=new JPanel();
	//private JLabel []lbl=new JLabel[10];
	private JLabel []lbl=new JLabel[SIZE];
	private JButton []btn=new JButton[SIZE];
	private JTextField []tf = new JTextField[SIZE];
	private JList<String>[]my_list=new JList[SIZE];
	private JScrollPane jsp=new JScrollPane() ;
	
	private JFrame MySQLServer=new JFrame();
	private JPanel pnl_SQL=new JPanel();
	private JLabel []lbl_SQL=new JLabel[SIZE];
	private JButton btn_SQL=new JButton();
	private JTextField []tf_SQL = new JTextField[SIZE];
	
	private JComboBox cbox=new JComboBox(list_combobox);

	private DefaultListModel<String> []model=new DefaultListModel[SIZE];

	//Wenn mir langweilig ist das noch mit reinnehmen
	//private JRadioButton radio_btn=new JRadioButton("Write output in file ?");
	
	private JPasswordField jpw_SQL=new JPasswordField();
	SQL sql=new SQL();
	
	public GUI(){//Konstruktor
			
		initMainField();
		
		/*
		model.addElement("eacea");
		model.addElement("mlefefiniq");
		model.addElement("oifewiin");
		model.addElement("ztuwgeoni34");
		*/
			
		//frame.setVisible(true);
		//frame.repaint();
		//**********************************************************
		
		initConnectionField();
		
		btn_SQL.doClick();
		
		//MySQLServer.setVisible(true);
		//MySQLServer.repaint();
	}
	public void actionPerformed (ActionEvent ae){

		
		if(ae.getSource() == this.btn[0]){
			
	        String searchString=tf[0].getText();
			String filter=String.valueOf(cbox.getSelectedItem());
			
			if(!searchString.isEmpty()){
				
				//searchString+" "+filter
				writeIntoConsole("Success: "+searchString+" "+filter);
				/*
				model[0].addElement(filter);
				
				switch(auswahl){
				case "Filme"://case list_combobox[0]://Thomas fragen
					{	//Tabellenname übergeben
						sql.query(userInput,"Tabellenname_film");
						break;
					}
				case "Autoren":
					{
						//Tabellenname übergeben
						sql.query(userInput,"Tabellenname_autoren");
						break;
					}
				case "Kinos": 
					{
						sql.query(userInput, "TabellenName_kino");
						break;
					}
				case "Wo laeuft der Film im Kino?":
					{
						//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
						sql.query(userInput, "Alle kinos where film=...");
						break;
					}
				case "Alle Filme in Kino ...":
					{
						//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
						sql.query(userInput, "alle filme where Kino =...");
						break;
					}
				default: 
					{
						System.err.println("Fehler");
						break;
					}
				}//End switch case
				
				
				sql.query(userInput,auswahl);
				*/
			}else{
				System.out.println("Eingabefeld darf nicht leer sein");
			}
			
		}
		if(ae.getSource()==this.btn_SQL){
			
			String serverIP=tf_SQL[0].getText();
			String username=tf_SQL[1].getText();
			String password=String.valueOf(jpw_SQL.getPassword());
			String port=tf_SQL[2].getText();
			String database=tf_SQL[3].getText();
			
			System.out.println("ServerIP: "+serverIP);
			System.out.println("port: "+port);
			System.out.println("Datenbank: "+database);
			System.out.println("Username: "+username);
			System.out.println("Password: "+password);
			
			
			
			System.out.println("Passwort ist: "+password+"    hoffe das das im klartext ist");
			
			if(jpw_SQL.getPassword().length==0){				
			
				JOptionPane.showMessageDialog(null,"Password field is empty.\nPress OK to continue.","Password Error",JOptionPane.ERROR_MESSAGE);
			
			}else{
				
				//int check=sql.check_connection(serverIP,port,database,username,password);
				int check=0;
				
				if(check==0){
					
					System.out.println("Die Verbindung zum Server steht");
					MySQLServer.dispose();	
					frame.setVisible(true);
					frame.repaint();
					
					
				}else{
					System.out.println("Error: Verbindung konnte nicht hergestellt werden.");
					JOptionPane.showMessageDialog(null,"Could not conncet to "+serverIP+".\nPlease Check your Input and check if the server is online.\nPress OK to continue.","Connection Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		
		 }//End btn_SQL ActionListener
	}//End ActionListener	
	private void initConnectionField(){
		
		MySQLServer.setTitle("Connection to MySQL Server");
		MySQLServer.setSize(350, 150);
		MySQLServer.setLocation(1000, 300);
		MySQLServer.setResizable(false);
		
		pnl_SQL.setLayout(null);
		
		MySQLServer.add(pnl_SQL);
			
		//Label ServerIP
		lbl_SQL[0]=new JLabel();
		lbl_SQL[0].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y);
		lbl_SQL[0].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[0].setText("Server IP:");
		
		//Label Port
		lbl_SQL[3]=new JLabel();
		lbl_SQL[3].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*3);
		lbl_SQL[3].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[3].setText("Port:");
		
		//Label Datenbank
		lbl_SQL[4]=new JLabel();
		lbl_SQL[4].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*5);
		lbl_SQL[4].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[4].setText("Datenbank:");
				
		//Label Username
		lbl_SQL[1]=new JLabel();
		lbl_SQL[1].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*7);
		lbl_SQL[1].setSize(100, LABEL_SIZE_Y);
		lbl_SQL[1].setText("Username:");
		
		//Label Password
		lbl_SQL[2]=new JLabel();
		lbl_SQL[2].setLocation(LABLE_LOCATION_X, LABLE_LOCATION_Y*9);
		lbl_SQL[2].setSize(LABEL_SIZE_X, LABEL_SIZE_Y);
		lbl_SQL[2].setText("Password:");
		
		
		//Textfield ServerIP
		tf_SQL[0]=new JTextField();
		tf_SQL[0].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE);
		tf_SQL[0].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Port
		tf_SQL[2]=new JTextField();
		tf_SQL[2].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*3);
		tf_SQL[2].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);

		//Textfield Datenbank
		tf_SQL[3]=new JTextField();
		tf_SQL[3].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*5);
		tf_SQL[3].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		
		//Textfield Username
		tf_SQL[1]=new JTextField();
		tf_SQL[1].setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*7);
		tf_SQL[1].setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
				
		//Textfield Password
		jpw_SQL.setLocation(TEXT_FIELD_LOCATION_X, TEXT_FIELD_DISTANCE*9);
		jpw_SQL.setSize(SIZE_OF_TEXTFIELD_X, SIZE_OF_TEXTFIELD_Y);
		//nachher löschen
		jpw_SQL.setText("a");
		
		//Connect Button
		btn_SQL.setLocation(135, 110);
		btn_SQL.setSize(150, 20);
		btn_SQL.setText("Connect ...");
		btn_SQL.addActionListener(this);
		
		//Alles dem Panel pnl_SQL hinzufügen 
		pnl_SQL.add(jpw_SQL);
		pnl_SQL.add(btn_SQL);
		pnl_SQL.add(lbl_SQL[0]);
		pnl_SQL.add(lbl_SQL[1]);
		pnl_SQL.add(lbl_SQL[2]);
		pnl_SQL.add(lbl_SQL[3]);
		pnl_SQL.add(lbl_SQL[4]);
		pnl_SQL.add(tf_SQL[0]);
		pnl_SQL.add(tf_SQL[1]);
		pnl_SQL.add(tf_SQL[2]);
		pnl_SQL.add(tf_SQL[3]);
		
	}
	private void initMainField(){

		frame.setSize(SIZE_MAIN_WINDOW_X,SIZE_MAIN_WINDOW_Y);
		frame.setLocation(LOCATION_MAIN_WINDOW_X,LOCATION_MAIN_WINDOW_Y);
		//frame.setLocation(1000, 400);
		frame.setResizable(false);
		
		pnl.setLayout(null);
		pnl.setBackground(Color.pink);
		frame.add(pnl);
		
		lbl[0]=new JLabel();
		lbl[0].setText("Suchbegriff:");
		lbl[0].setBounds(0, 10, 200, 20);
		
		lbl[1]=new JLabel();
		lbl[1].setBounds(260, 10, 100, 20);
		lbl[1].setText("Filter");
		
		lbl[2]=new JLabel();
		lbl[2].setText("Console:");
		lbl[2].setBounds(10, 400, 200, 20);
		
		btn[0]=new JButton();
		btn[0].setLocation(475, 30);
		btn[0].setSize(100, 25);
		btn[0].setText("Suchen");
		btn[0].addActionListener(this);		
		
		tf[0] =new JTextField();
		tf[0].setSize(250, 25);
		tf[0].setLocation(1, 30);
		
		cbox.setLocation(260, 30);
		cbox.setSize(200, 30);
		//cbox.addActionListener(this);
		
		

		//Konsole Liste
		model[0]=new DefaultListModel<String>();
		
		my_list[0]=new JList<String>(model[0]);
		my_list[0].setBackground(Color.yellow);
		/*
		my_list[0].setLocation(10, 425);
		my_list[0].setSize(500, 150);
		*/
		
		jsp.getViewport().add(my_list[0]);
		jsp.setBounds(10, 425, 500, 150);
		jsp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);	
		
		//Ausgabe Ĺiste
		model[1]=new DefaultListModel<String>();
		
		my_list[1]=new JList<String>(model[1]);
		my_list[1].setLocation(330, 100);
		my_list[1].setSize(300, 150);
		my_list[1].setBackground(Color.green);
		
		
		pnl.add(jsp);
		//Die Liste brauch ich nicht hinzuzufügen den das ist schon in dem scrollpanel drin
		//pnl.add(my_list[0]);	
		pnl.add(my_list[1]);
		pnl.add(lbl[1]);
		pnl.add(lbl[2]);
		pnl.add(cbox);
		pnl.add(lbl[0]);
		pnl.add(btn[0]);
		pnl.add(tf[0]);
		
	}
	private void writeIntoConsole(String text){
		
		model[0].addElement(text);
		
		int lastIndex=my_list[0].getModel().getSize()-1;
		if(lastIndex>=0){
			
			my_list[0].ensureIndexIsVisible(lastIndex);
		}
	}
}

































