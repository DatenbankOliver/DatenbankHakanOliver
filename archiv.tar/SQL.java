import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class SQL {
	
	final String AUSWAHL_FILME ="Filme";
	final String AUSWAHL_AUTOREN ="Autoren";
	final String AUSWAHL_KINOS ="Kinos";
	final String AUSWAHL_WO_LAUEFT_WAS= "Wo laeuft der Film im Kino?";
	final String AUSWAHL_FILME_IN_KINOS= "Alle Filme in Kino ...";
	final String AUSWAHL_ALLE_FILME ="Alle Filme";
	final String AUSWAHL_ALLE_KINOS ="Alle Kinos";
	
	final String TABELLE_TEST="person";
	final String KEY="0000000000";
	
	public static int eintraege=0;
	Connection con;
	
	public int check_connection(String serverIP,String port,String databaseName,String username,String password){//Die Funktion wird nur gebraucht um die Verbindung zum SQL-Server zu checken
		System.out.println("Jetzt wird die Verbindung zum Server geprueft. 0-> alles gut; -1-> Fehler");
		
		try{
			String host="jdbc:mysql://"+serverIP+":"+port+"/"+databaseName+"?useSSL=true";
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con=DriverManager.getConnection(host,username,password);
			
			String abfrage="SELECT * FROM sql_connection;";

			con.setReadOnly(true);
			
			Statement state=con.createStatement();
			
			ResultSet result=state.executeQuery(abfrage);
			if(result.next()){
				if(result.getString(1).equals(KEY)){
					
					System.out.println("SUCCESS Connection My-SQL Server");
					return 0;
				}else{
					System.out.println("Failed Connection to My-SQL Server");
					JOptionPane.showMessageDialog(null,"Failed to Connect to My-SQL Server","Failed",JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}catch(Exception e){
			System.out.println("Fehler: "+e);
		}	
		return -1;
	}
	public ArrayList<String> query(String bedingung,String auswahl){
		
		ArrayList<String> ergebnisListe=new ArrayList<String>();
		
		if(!parseUserInput(bedingung)){
		
			try{
			/*	public final String list_combobox[]={"Filme","Autoren","Kinos","Wo laeuft der Film im Kino?","Alle Filme in Kino ...","Alle Filme", "Alle Kinos"};*/
				String statement="";
				switch (auswahl){	
					case AUSWAHL_FILME:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_AUTOREN:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_KINOS:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_WO_LAUEFT_WAS:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_FILME_IN_KINOS:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_ALLE_FILME:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					case AUSWAHL_ALLE_KINOS:
						{
							statement="Select * from "+TABELLE_TEST+" where male=\""+bedingung+"\";";
							eintraege=6;//Wieviele Spalten werden ausgegeben
							break;
						}
					default:
						{
							System.out.println("Fehler SQL.Query function");
							break;
						}
				}//End switch case
		
				Statement state=con.createStatement();
				ResultSet rs=state.executeQuery(statement);//Abfrage senden
				
				int spalten=0;//Wir wollen jetzt errechnen wieviele Spalten wir zurück bekommen
	
				ergebnisListe.add(Integer.toString(eintraege));
				if(rs.next()){		
					while(rs.next()){
						spalten++;				
						for(int i=1;i<=eintraege;i++){
							
							ergebnisListe.add(rs.getString(i));//Die ausgabe wird in die Liste geschrieben
						}
					}
					
				}else{
					ergebnisListe.clear();
					return ergebnisListe;
				}
				
			}catch(Exception e){
				System.out.println("Fehler: "+e);
			}			
		}else{
			Injection();//User versucht eine SQL Injection
		}
		return ergebnisListe;
	}
	public ArrayList<String> getAllColumns(String tabellenName,ArrayList<String> ergebnisListe){
		
		try{
			Statement state=con.createStatement();
			ResultSet rs=state.executeQuery("show columns from "+tabellenName);
			while(rs.next()){
				ergebnisListe.add(rs.getString(1));
			}
		}catch(Exception e){
			System.out.println("Fehler: "+e);
		}
		return ergebnisListe;
	}
	private	boolean parseUserInput(String toParse){//Try to check that the user does not try SQL Injection

		if(!toParse.toLowerCase().contains("drop")){//All das darf nicht in der Abfrage drin sein
			if(!toParse.toLowerCase().contains("--")){
				if(!toParse.toLowerCase().contains("pwd")){
					if(!toParse.toLowerCase().contains("trusted")){
						if(!toParse.toLowerCase().contains("exec")){
							if(!toParse.toLowerCase().contains("/")){
								if(!toParse.toLowerCase().contains("\\")){
									if(!toParse.toLowerCase().contains("?")){
										return false;
									}
								}
							}
						}
					}
				}
			}
		}
		return true;
	}
	private void Injection(){
		JOptionPane.showMessageDialog(null,"Versuchte SQL Injection!","SQL Injection",JOptionPane.ERROR_MESSAGE);
		System.exit(0);//Close Program
	}

}//END CLASS SQL

