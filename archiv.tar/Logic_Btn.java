import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Logic_Btn extends GUI{
	
	final static String TEXTFIELD_EMPTY="ERROR: Eingabefeld darf nicht leer sein";
	
	//Hier für jedes DropDown Menü ein Array anlegen
	final String [] film_Spaltennamen={"Name","Vorname","Alter","Land","Gehalt","Sex"};
	final String [] autoren_Spaltennamen={};
	final String [] kinos_Spaltennamen={};
	final String [] welcher_film_laeuft_wo_Spaltennamen={};
	final String [] alle_kinos_in_Spaltennamen={};
	final String [] alle_kinosSpaltennamen={};
	final String [] alle_filme_Spaltennamen={};
	
	public Logic_Btn(){//Init nothing
		
		System.out.println("Konstruktor Logic_Btn");
		
	}
	public boolean writeIntoConsole(String text){//Eine Funktion um in die Console zu schreiben
		
		try {	
			model[0].addElement(text);//Add text to list
			int lastIndex=my_list[0].getModel().getSize()-1;//Need for moving the element to the bottom
			
			if(lastIndex >= 0){
				
				my_list[0].ensureIndexIsVisible(lastIndex);//Move the element to the bottom of the list
			}
			return true;
			
		} catch (Exception e) {
			System.out.println("Exception Write into Console: "+e);
			return false;
		}
	}
	public Vector createDataVector(String input,int size){//Brauch ich um Spalten hinzuzufügen/ Das macht man mit Vectoren und zwar so
		
		Vector vector= new Vector(size);
		
		for(int i=0; i<size;i++){
			
			vector.add(input);
		}
		return vector;
	}
	
	//Logik Buttons
	public void Action_Btn_SQL(){
		
		//Save the input from Textfields into some variables  
		//Muss nachher weg
		String serverIP=tf_SQL[0].getText();
		String username=tf_SQL[1].getText();
		String password=String.valueOf(jpw_SQL.getPassword());
		String port=tf_SQL[2].getText();
		String database=tf_SQL[3].getText();
		
		if(password.length()==0){				
			//This will execute when the Passwordfield is empty
			//Error Message will be printed in an extra window
			JOptionPane.showMessageDialog(null,"Password field is empty.\nPress OK to continue.","Password Error",JOptionPane.ERROR_MESSAGE);
		
		}else{
			
			//0 for sql_connection success; -1 for failed 
			int check=sql.check_connection(serverIP,port,database,username,password);
			
			if(check==0){
								
				System.out.println("Die Verbindung zum Server steht");
				cl.show(cards, "b");//Switch the Panel to the Main Panel
				setSize(SIZE_MAIN_WINDOW_X,SIZE_MAIN_WINDOW_Y);//Set another Size
				setLocation(LOCATION_MAIN_WINDOW_X,LOCATION_MAIN_WINDOW_Y);//
				
			}else{
				//Error Message Window
				JOptionPane.showMessageDialog(null,"Could not conncet to "+serverIP+".\nPlease Check your Input and check if the server is online.\nPress OK to continue.","Connection Error",JOptionPane.ERROR_MESSAGE);
			}
		}//End else Password.length()==0
	}//End Function
	public void Action_Btn_Search(){
	
		//https://wiki.byte-welt.net/wiki/JTable_(Tutorial)
		/*
		//Zeile hinzufügen
		int size=tablemodel.getColumnCount();
		//Vector newDatas=createDataVector("row",size);		
		Vector newDatas=createDataVectorInputOnly("test123",size);		
		tablemodel.addRow(newDatas);
		
		//Spalte hinzufügen
		size=tablemodel.getRowCount();
		//Vector newDatas=createDataVector("column", size);
		newDatas=createDataVector("column", size);
		String name=String.valueOf(tablemodel.getColumnCount());
		tablemodel.addColumn(name,newDatas);
		
		
		//Delete Row
		//int size = tablemodel.getRowCount();//Check ob das element zum löschen größer 0 und
											//kleiner als das letzte element
		int index = 0;
		//tablemodel.removeRow( index );
		
		
		//TableModel mydata=new MyTableModel();
		/*
		rowData.add("hello");
		rowData.add("ves");
		
		columnName.add("aec");
		columnName.add("vsdk");
		*/
		//jsp[0].updateUI();
		
		
		
		//jsp[0]=new JScrollPane(table);
		//logic_Action.tabelleFuellen(table,jsp[0]);
		//writeIntoConsole("Btn Search pressed");
		
		String searchString=tf[0].getText();
		
		if(!searchString.isEmpty()){

			pnl[1].add(jsp[0]);	
			clear_Row_Column();
			
			//Read the Filter
			String filter=String.valueOf(cbox.getSelectedItem());//Den Filter (DropDown Menu) abfragen welcher String gerade ausgewählt ist
			
			writeIntoConsole("Suchstring und Filter: "+searchString+" "+filter);	
			
			//6 spalten zurück
			ArrayList<String> ergebnis_query= sql.query(searchString, filter);//Die Abfrage machen und eine Liste mit dem Ergebnis zurückbekommen. 
																			  //Als erster Eintrag steht die Anzahl der Spalten drin
			if(sqlQueryEmpty(ergebnis_query)){//Wenn die Ergebnisspalte leer ist dann gehen wir zurück
				writeIntoConsole("Keine Uebereinstimmung gefunden");
				return;
			}
			
			int eine_zeile_ist_wie_lanng=Integer.valueOf(ergebnis_query.get(0));//Die Anzahl der Spalten zwischenspeichern
			ergebnis_query.remove(0);//Den ersten eintrag löschen sonst wird der noch ausversehn verwendet
			ArrayList<String>spaltennamen=new ArrayList<String>();//Eine Liste bauen
			
			switch (filter) {
				case "Filme":
				{
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Autoren":
				{
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Kinos": 
				{
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Wo laeuft der Film im Kino?":
				{
					//Aber hier anstatt Alle Kinos where... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					//sql.query(userInput, "Alle kinos where film=...");
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Alle Filme in Kino ...":
				{
					//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					//sql.query(userInput, "alle filme where Kino =...");
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Alle Filme":
				{
					//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					//sql.query(userInput, "alle filme where Kino =...");
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				case "Alle Kinos":
				{
					//Aber hier anstatt Alle Kinos whe... einfach ein kurzen String übergeben sodass ich in sql.query weiß was die machen soll
					//sql.query(userInput, "alle filme where Kino =...");
					spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
					break;
				}
				default:
				{
					writeIntoConsole("Fehler bei dem DropDown Menu");
					System.out.println(TEXTFIELD_EMPTY);
					break;
				}
			}//End Switch Case
			
			//Die untere Zeile bitte rausnehmen denn ich habe in der switch case anweisung dass alles schon stehen
			//spaltennamen.addAll(Arrays.asList(film_Spaltennamen));//In die Liste die Namen der Spalten von Film ablegen
			addSpalte(spaltennamen);//Die Spalten erzeugen
			
			//Liste "spaltennamen" wird mehrmals verwendet
			spaltennamen.clear();//Leeren weil wir den inhalt nicht mehr brauchen
			
			for(int i=0;i<=ergebnis_query.size();i++){//Jetzt die Zeilen "bauen" Dazu werden immer die "Anzahl der Spalten" als Trennvariable genutzt
				
				if(i==eine_zeile_ist_wie_lanng){//Wenn eine Zeile komplett ist dann füge die Zeile hinzu
					
					addZeile(spaltennamen);//Zeile hinzufügen
					spaltennamen.clear();//Löschen den die Zeilen sind jetzt hoffentlich schon sichtbar sonst den Entwickler anschreiben
					ergebnis_query.subList(0, i).clear();//Da hier schon eine Zeile hinzugefügt wurde brauchen wir die Daten nicht mehr also wird genau dieser Bereich gelöscht
					i=0;
					if(ergebnis_query.size()==0){break;}//Damit ich nicht in der Schleife feststecke
				}
				spaltennamen.add(ergebnis_query.get(i));//In die liste "spal..." meine  zeilen speichern
			}//End For Loop
		
			}else{//What happens when the inputtextfield is emtpy
				writeIntoConsole("Eingabefeld darf nicht leer sein");
			}
	}//End function
	public void Action_Next(){
		
		writeIntoConsole("Button Next pressed");
		//Function nextÜbersicht erstellen und es wird ein Vector zurückgegeben 
		//In der Function wird eine abfrage erstellt und in Vectoren gespeichert / Aber nur ein Zeile wird in den Vector gespeichert
		lbl[4].setText("Kino A");
		lbl[6].setText("Film B");
		lbl[7].setText("Film C");
		lbl[8].setText("Film D");
	}
	public void Action_Previous(){
		//Siehe Action_Next
		writeIntoConsole("Button Previous");
	}
	public void addZeile(ArrayList<String> zeileneingaben){
		
		//https://wiki.byte-welt.net/wiki/JTable_(Tutorial)
		int size_of_columns=tablemodel.getColumnCount();//Hier gebe ich mir die Anzahl der Spalten
		Vector one_Row=new Vector();//Um eine Zeile zu befüllen schreibe ich in den Vector alle meine Daten;
									//Hat die Tabelle 3 Spalten dann darf der Vector höchstens 3 groß sein
		for(int i=0;i<zeileneingaben.size();i++){

			one_Row.add(zeileneingaben.get(i));//In den Vector kommen meine Zeilennamen
		}
		tablemodel.addRow(one_Row);//Zeile wird hinzugefügt
	}
	public void addSpalte(ArrayList<String>spaltennamen){//Spalten hinzufügen / Alle Spalten müssen als Liste übergeben werden
		
		for(int j=0;j<spaltennamen.size();j++){//In die Console (GUI) schreiben welche Tabelle hinzugefügt werden
			
			writeIntoConsole("Spalte "+spaltennamen.get(j)+" wird hinzugefügt");
		}
				
		for(int i=0;i<spaltennamen.size();i++){//Alles was in der Liste steht wird als neue Spalte hinzgefügt
			
			tablemodel.addColumn(spaltennamen.get(i));
			writeIntoConsole("Spalte "+spaltennamen.get(i)+" hinzugefügt");
		}
	}
	public boolean sqlQueryEmpty(ArrayList<String> result){//Prueft ob die SQL abfrgae eine leere liste zurückliefert
		
		return result.size()==0 ? true : false;
	}
	public void clear_Row_Column(){//Zeilen und Spalten löschen
		
		tablemodel.setRowCount(0);
		tablemodel.setColumnCount(0);
	}

}
